<template>
  <div class="error-container" v-if="message">
    <el-alert
      :title="message"
      type="error"
      show-icon
      :closable="false"
    >
      <div class="error-details" v-if="details">
        <el-collapse>
          <el-collapse-item title="详细信息">
            <pre>{{ details }}</pre>
          </el-collapse-item>
        </el-collapse>
      </div>
    </el-alert>
  </div>
</template>

<script>
export default {
  name: 'ErrorMessage',
  props: {
    message: {
      type: String,
      default: ''
    },
    details: {
      type: [String, Object],
      default: null
    }
  }
}
</script>

<style scoped>
.error-container {
  margin-bottom: 20px;
}
.error-details {
  margin-top: 10px;
  max-height: 200px;
  overflow: auto;
}
pre {
  white-space: pre-wrap;
  font-size: 12px;
}
</style> 