import { createStore } from 'vuex'
import axios from 'axios'
import { API_URL } from '../api/config'

console.log('API URL:', API_URL)

// 配置axios
axios.defaults.withCredentials = false
axios.interceptors.response.use(
  response => response,
  error => {
    console.error('Axios error:', error)
    return Promise.reject(error)
  }
)

export default createStore({
  state: {
    history: [],
    currentFile: null,
    analysisResult: null,
    imageUrl: null,
    uploadProgress: 0,
    imageGenerationProgress: 0
  },
  getters: {
    uploadHistory: state => state.history,
    currentFile: state => state.currentFile,
    analysisResult: state => state.analysisResult,
    imageUrl: state => state.imageUrl,
    uploadProgress: state => state.uploadProgress,
    imageGenerationProgress: state => state.imageGenerationProgress
  },
  mutations: {
    SET_HISTORY(state, history) {
      state.history = history
    },
    SET_CURRENT_FILE(state, file) {
      state.currentFile = file
    },
    SET_ANALYSIS_RESULT(state, result) {
      state.analysisResult = result
    },
    SET_IMAGE_URL(state, url) {
      state.imageUrl = url
    },
    SET_UPLOAD_PROGRESS(state, progress) {
      state.uploadProgress = progress
    },
    SET_IMAGE_GENERATION_PROGRESS(state, progress) {
      state.imageGenerationProgress = progress
    }
  },
  actions: {
    async fetchHistory({ commit }) {
      try {
        const response = await axios.get(`${API_URL}/history`)
        commit('SET_HISTORY', response.data)
        return response.data
      } catch (error) {
        console.error('Error fetching history:', error)
        return []
      }
    },
    async uploadFile({ commit }, { file, onProgress }) {
      const formData = new FormData()
      formData.append('file', file)
      
      try {
        console.log('Uploading file:', file.name)
        const response = await axios.post(`${API_URL}/upload`, formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
            'Accept': 'application/json'
          },
          withCredentials: false,
          onUploadProgress: progressEvent => {
            const progress = Math.round((progressEvent.loaded * 100) / progressEvent.total)
            console.log('Upload progress:', progress)
            commit('SET_UPLOAD_PROGRESS', progress)
            if (onProgress) onProgress(progress)
          }
        })
        console.log('Upload response:', response.data)
        return response.data
      } catch (error) {
        console.error('Error uploading file:', error)
        console.error('Response:', error.response?.data)
        throw error
      }
    },
    async analyzeFile({ commit }, id) {
      try {
        const response = await axios.get(`${API_URL}/analyze/${id}`)
        commit('SET_ANALYSIS_RESULT', response.data)
        return response.data
      } catch (error) {
        console.error('Error analyzing file:', error)
        throw error
      }
    },
    async generateImage({ commit }, prompt) {
      try {
        commit('SET_IMAGE_GENERATION_PROGRESS', 10)
        const response = await axios.post(`${API_URL}/generate-image`, { prompt })
        commit('SET_IMAGE_URL', response.data.url)
        commit('SET_IMAGE_GENERATION_PROGRESS', 100)
        return response.data.url
      } catch (error) {
        console.error('Error generating image:', error)
        commit('SET_IMAGE_GENERATION_PROGRESS', 0)
        throw error
      }
    }
  }
}) 