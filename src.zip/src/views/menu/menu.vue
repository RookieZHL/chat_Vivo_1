<template>
  <div class="container">
    <h1 class="title">欢迎使用蓝心模型平台</h1>
    <div class="content">
      <div class="feature-box" @click="navigateTo('/home')">
        <h2>蓝心聊天</h2>
      </div>
      <div class="feature-box" @click="navigateTo('/upload')">
        <h2>文件总结</h2>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useRouter } from "vue-router";

const router = useRouter();

const navigateTo = (path) => {
  router.push(path);
};
</script>

<style scoped>
.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.title {
  text-align: center;
  margin-bottom: 60px;
  font-size: 50px;
  color: #333;
}

.content {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 0;
  position: relative;
}

.feature-box {
  width: 300px;
  height: 300px;
  border: 2px solid #ddd;
  border-radius: 8px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-end;
  cursor: pointer;
  transition: all 0.3s ease;
  margin: 0 40px;
  padding-bottom: 30px;
  background-size: 160px 160px;
  background-position: center 40px;
  background-repeat: no-repeat;
}

.feature-box:first-child {
  background-image: url("../../../public/chat-icon.svg");
}

.feature-box:last-child {
  background-image: url("../../../public/file-icon.svg");
}

.content::before {
  content: "";
  position: absolute;
  left: 50%;
  top: 10%;
  height: 80%;
  width: 2px;
  background-color: #ddd;
  transform: translateX(-50%);
}

.feature-box:hover {
  border-color: #42b883;
  transform: translateY(-5px);
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.feature-box h2 {
  margin: 0;
  font-size: 32px;
  color: #666;
}

.feature-box:hover h2 {
  color: #42b883;
}
</style>
