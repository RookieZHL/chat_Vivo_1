<template>
  <div class="upload-page">
    <div class="container">
      <h1 class="page-title">文档分析工具</h1>
      
      <!-- 错误信息 -->
      <error-message :message="errorMessage" :details="errorDetails" />
      
      <!-- 调试信息 -->
      <div v-if="showDebug" class="card debug-area">
        <h3>调试信息</h3>
        <p><strong>API URL:</strong> {{ apiUrl }}</p>
        <el-button size="small" @click="testBackend">测试后端连接</el-button>
        <div v-if="backendStatus" class="debug-result">
          <p>后端状态: {{ backendStatus.ok ? '正常' : '异常' }}</p>
          <pre v-if="backendStatus.response">{{ backendStatus.response }}</pre>
        </div>
      </div>
      
      <!-- 上传区域 -->
      <div class="card upload-area">
        <el-upload
          class="upload-container"
          drag
          action="#"
          :http-request="handleUpload"
          :before-upload="beforeUpload"
          :show-file-list="false"
          :multiple="false"
        >
          <el-icon class="el-icon--upload"><upload-filled /></el-icon>
          <div class="el-upload__text">
            拖拽文件到此处或 <em>点击上传</em>
          </div>
          <template #tip>
            <div class="el-upload__tip">
              支持上传PDF、Word和TXT文件（最大16MB）
            </div>
          </template>
        </el-upload>
        
        <div v-if="isUploading" class="upload-progress">
          <el-progress :percentage="uploadProgress" />
          <div class="progress-text">正在上传: {{ uploadingFile.name }}</div>
        </div>
      </div>
      
      <!-- 历史记录 -->
      <div class="card history-area">
        <div class="history-header">
          <h2 class="section-title">上传历史</h2>
          <el-button size="small" @click="fetchHistory" :loading="loading">刷新</el-button>
        </div>
        
        <el-table
          :data="history"
          style="width: 100%"
          v-loading="loading"
          empty-text="暂无上传记录"
        >
          <el-table-column prop="filename" label="文件名" min-width="200" />
          <el-table-column prop="type" label="类型" width="120">
            <template #default="scope">
              <el-tag
                :type="getFileTypeTagType(scope.row.type)"
                effect="plain"
              >
                {{ getFileTypeLabel(scope.row.type) }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="time" label="上传时间" width="180" />
          <el-table-column fixed="right" label="操作" width="120">
            <template #default="scope">
              <el-button
                type="primary"
                text
                @click="viewAnalysis(scope.row.id)"
              >
                查看
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
    
    <!-- 分析对话框 -->
    <el-dialog
      v-model="analyzeDialogVisible"
      title="文档分析"
      width="30%"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :show-close="false"
    >
      <p>是否对上传的文档进行分析?</p>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="cancelAnalyze">否</el-button>
          <el-button type="primary" @click="confirmAnalyze">是</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { ref, onMounted, computed } from 'vue'
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { UploadFilled } from '@element-plus/icons-vue'
import ErrorMessage from '@/components/ErrorMessage.vue'
import { API_URL } from '@/api/config'
import axios from 'axios'

export default {
  name: 'UploadView',
  components: {
    UploadFilled,
    ErrorMessage
  },
  setup() {
    const store = useStore()
    const router = useRouter()
    
    const loading = ref(false)
    const isUploading = ref(false)
    const uploadingFile = ref(null)
    const lastUploadedId = ref(null)
    const analyzeDialogVisible = ref(false)
    const errorMessage = ref('')
    const errorDetails = ref(null)
    const showDebug = ref(true) // 开发环境显示调试信息
    const apiUrl = ref(API_URL)
    const backendStatus = ref(null)
    
    const history = computed(() => store.getters.uploadHistory)
    const uploadProgress = computed(() => store.getters.uploadProgress)
    
    const fetchHistory = async () => {
      loading.value = true
      errorMessage.value = ''
      try {
        console.log('Fetching history...')
        await store.dispatch('fetchHistory')
        console.log('History:', history.value)
      } catch (error) {
        console.error('Error fetching history:', error)
        errorMessage.value = '加载历史记录失败'
        errorDetails.value = error.toString()
        ElMessage.error('加载历史记录失败')
      } finally {
        loading.value = false
      }
    }
    
    const getFileTypeLabel = (type) => {
      const types = {
        pdf: 'PDF',
        docx: 'Word',
        txt: 'Text'
      }
      return types[type] || type.toUpperCase()
    }
    
    const getFileTypeTagType = (type) => {
      const types = {
        pdf: 'danger',
        docx: 'primary',
        txt: 'success'
      }
      return types[type] || 'info'
    }
    
    const beforeUpload = (file) => {
      const extension = file.name.split('.').pop().toLowerCase()
      const isAllowed = ['pdf', 'docx', 'txt'].includes(extension)
      
      if (!isAllowed) {
        ElMessage.error('只支持上传PDF、Word和TXT文件!')
        return false
      }
      
      const isLessThan16M = file.size / 1024 / 1024 < 16
      if (!isLessThan16M) {
        ElMessage.error('文件大小不能超过16MB!')
        return false
      }
      
      return true
    }
    
    const handleUpload = async (options) => {
      const file = options.file
      isUploading.value = true
      uploadingFile.value = file
      errorMessage.value = ''
      
      try {
        console.log('Starting upload of file:', file.name)
        const result = await store.dispatch('uploadFile', {
          file,
          onProgress: (progress) => {
            console.log(`Upload progress: ${progress}%`)
          }
        })
        
        console.log('Upload result:', result)
        if (result && result.id) {
          lastUploadedId.value = result.id
          // 显示分析对话框
          analyzeDialogVisible.value = true
          
          // 刷新历史记录
          await fetchHistory()
        } else {
          ElMessage.error('服务器返回的数据格式不正确')
          errorMessage.value = '服务器返回的数据格式不正确'
          errorDetails.value = JSON.stringify(result, null, 2)
        }
      } catch (error) {
        console.error('Upload error details:', error)
        
        if (error.response) {
          console.error('Error response:', error.response.data)
          errorMessage.value = '文件上传失败'
          errorDetails.value = JSON.stringify(error.response.data, null, 2)
          ElMessage.error(`文件上传失败: ${error.response.data.error || '未知错误'}`)
        } else if (error.request) {
          console.error('Error request:', error.request)
          errorMessage.value = '服务器无响应'
          errorDetails.value = '请检查后端服务是否启动'
          ElMessage.error('服务器无响应，请检查后端服务是否启动')
        } else {
          console.error('Error message:', error.message)
          errorMessage.value = '上传错误'
          errorDetails.value = error.message
          ElMessage.error(`上传错误: ${error.message}`)
        }
      } finally {
        isUploading.value = false
      }
    }
    
    const viewAnalysis = (id) => {
      router.push({ name: 'analysis', params: { id } })
    }
    
    const confirmAnalyze = () => {
      analyzeDialogVisible.value = false
      if (lastUploadedId.value) {
        router.push({ name: 'analysis', params: { id: lastUploadedId.value } })
      }
    }
    
    const cancelAnalyze = () => {
      analyzeDialogVisible.value = false
      // 刷新历史记录
      fetchHistory()
    }
    
    const testBackend = async () => {
      try {
        const response = await axios.get(apiUrl.value)
        backendStatus.value = {
          ok: true,
          response: response.data
        }
      } catch (error) {
        backendStatus.value = {
          ok: false,
          response: error.toString()
        }
      }
    }
    
    onMounted(() => {
      fetchHistory()
      testBackend()
    })
    
    return {
      history,
      loading,
      isUploading,
      uploadingFile,
      uploadProgress,
      analyzeDialogVisible,
      errorMessage,
      errorDetails,
      showDebug,
      apiUrl,
      backendStatus,
      getFileTypeLabel,
      getFileTypeTagType,
      beforeUpload,
      handleUpload,
      viewAnalysis,
      confirmAnalyze,
      cancelAnalyze,
      fetchHistory,
      testBackend
    }
  }
}
</script>

<style scoped>
.upload-page {
  min-height: 100vh;
  padding-top: 30px;
  padding-bottom: 50px;
}

.upload-area {
  margin-bottom: 30px;
}

.upload-container {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
}

.section-title {
  font-size: 18px;
  font-weight: 600;
  margin-bottom: 20px;
  color: #303133;
}

.upload-progress {
  margin-top: 20px;
}

.progress-text {
  margin-top: 8px;
  font-size: 14px;
  color: #606266;
}

.history-area {
  margin-top: 20px;
}

.history-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.debug-area {
  margin-bottom: 20px;
  padding: 15px;
  background-color: #f8f9fa;
  border-left: 4px solid #909399;
}

.debug-result {
  margin-top: 10px;
  padding: 10px;
  background-color: #f0f0f0;
  border-radius: 4px;
  font-size: 12px;
}
</style> 