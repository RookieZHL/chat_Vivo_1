<template>
  <div class="analysis-page">
    <div class="container">
      <div class="header-section">
        <el-button @click="goBack" text icon="ArrowLeft">返回</el-button>
        <h1 class="page-title">
          文档分析: {{ analysisResult?.filename || '加载中...' }}
        </h1>
      </div>
      
      <el-row :gutter="20" v-loading="loading">
        <!-- 左侧文档信息 -->
        <el-col :span="8">
          <div class="card document-info">
            <h2 class="section-title">文档信息</h2>
            <template v-if="analysisResult">
              <div class="info-item">
                <span class="label">文件名:</span>
                <span class="value">{{ analysisResult.filename }}</span>
              </div>
              <div class="info-item">
                <span class="label">类型:</span>
                <span class="value">
                  <el-tag :type="getFileTypeTagType(analysisResult.type)" effect="plain">
                    {{ getFileTypeLabel(analysisResult.type) }}
                  </el-tag>
                </span>
              </div>
            </template>
          </div>
        </el-col>
        
        <!-- 右侧总结内容 -->
        <el-col :span="16">
          <div class="card summary-content">
            <div class="summary-header">
              <h2 class="section-title">AI 文档总结</h2>
              <el-button
                type="primary"
                size="small"
                @click="downloadSummary"
                icon="Download"
              >
                下载总结
              </el-button>
            </div>
            
            <div class="summary-box">
              <p v-if="analysisResult">{{ analysisResult.summary }}</p>
              <el-skeleton v-else :rows="6" animated />
            </div>
            
            <div class="ai-drawing">
              <div class="drawing-header">
                <h3 class="subsection-title">AI 绘画</h3>
                <el-button
                  type="primary"
                  @click="generateImage"
                  :loading="generating"
                  :disabled="!analysisResult || generating"
                >
                  生成图片
                </el-button>
              </div>
              
              <div v-if="generating" class="generation-progress">
                <el-progress :percentage="generationProgress" />
                <p class="progress-text">图片生成中，请稍候...</p>
              </div>
              
              <div v-if="imageUrl" class="image-result">
                <div class="image-url">
                  <p>图片已生成:</p>
                  <el-link :href="imageUrl" target="_blank" type="primary">{{ imageUrl }}</el-link>
                </div>
                <div class="image-actions">
                  <el-button type="success" @click="openImage">打开图片</el-button>
                  <el-button @click="downloadImage">下载图片</el-button>
                </div>
              </div>
            </div>
          </div>
        </el-col>
      </el-row>
    </div>
    
    <!-- 图片查看对话框 -->
    <el-dialog
      v-model="imageDialogVisible"
      title="是否查看生成的图片?"
      width="30%"
    >
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="imageDialogVisible = false">否</el-button>
          <el-button type="primary" @click="confirmViewImage">是</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { ref, computed, onMounted } from 'vue'
import { useStore } from 'vuex'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage, ElLoading } from 'element-plus'

export default {
  name: 'AnalysisView',
  props: {
    id: {
      type: String,
      required: true
    }
  },
  setup(props) {
    const store = useStore()
    const router = useRouter()
    const route = useRoute()
    
    const loading = ref(true)
    const generating = ref(false)
    const imageDialogVisible = ref(false)
    
    const analysisResult = computed(() => store.getters.analysisResult)
    const imageUrl = computed(() => store.getters.imageUrl)
    const generationProgress = computed(() => store.getters.imageGenerationProgress)
    
    const goBack = () => {
      router.push({ name: 'upload' })
    }
    
    const getFileTypeLabel = (type) => {
      const types = {
        pdf: 'PDF',
        docx: 'Word',
        txt: 'Text'
      }
      return types[type] || type.toUpperCase()
    }
    
    const getFileTypeTagType = (type) => {
      const types = {
        pdf: 'danger',
        docx: 'primary',
        txt: 'success'
      }
      return types[type] || 'info'
    }
    
    const fetchAnalysis = async () => {
      loading.value = true
      try {
        await store.dispatch('analyzeFile', props.id)
      } catch (error) {
        ElMessage.error('加载分析结果失败')
      } finally {
        loading.value = false
      }
    }
    
    const downloadSummary = () => {
      if (!analysisResult.value) return
      
      const text = analysisResult.value.summary
      const filename = `${analysisResult.value.filename.split('.')[0]}_summary.txt`
      
      const element = document.createElement('a')
      element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text))
      element.setAttribute('download', filename)
      element.style.display = 'none'
      document.body.appendChild(element)
      element.click()
      document.body.removeChild(element)
    }
    
    const generateImage = async () => {
      if (!analysisResult.value || generating.value) return
      
      generating.value = true
      try {
        await store.dispatch('generateImage', analysisResult.value.summary)
        imageDialogVisible.value = true
      } catch (error) {
        ElMessage.error('生成图片失败')
      } finally {
        generating.value = false
      }
    }
    
    const confirmViewImage = () => {
      imageDialogVisible.value = false
      if (imageUrl.value) {
        window.open(imageUrl.value, '_blank')
      }
    }
    
    const openImage = () => {
      if (imageUrl.value) {
        window.open(imageUrl.value, '_blank')
      }
    }
    
    const downloadImage = async () => {
      if (!imageUrl.value) return
      
      // 使用fetch获取图片并下载
      try {
        const response = await fetch(imageUrl.value)
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `ai_drawing_${Date.now()}.png`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
      } catch (error) {
        ElMessage.error('下载图片失败')
      }
    }
    
    onMounted(() => {
      fetchAnalysis()
    })
    
    return {
      loading,
      analysisResult,
      generating,
      imageUrl,
      generationProgress,
      imageDialogVisible,
      goBack,
      getFileTypeLabel,
      getFileTypeTagType,
      downloadSummary,
      generateImage,
      confirmViewImage,
      openImage,
      downloadImage
    }
  }
}
</script>

<style scoped>
.analysis-page {
  min-height: 100vh;
  padding-top: 30px;
  padding-bottom: 50px;
}

.header-section {
  display: flex;
  align-items: center;
  margin-bottom: 20px;
}

.header-section .page-title {
  margin-left: 20px;
  margin-bottom: 0;
}

.section-title {
  font-size: 18px;
  font-weight: 600;
  margin-bottom: 16px;
  color: #303133;
}

.subsection-title {
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 12px;
  color: #303133;
}

.document-info {
  height: 100%;
}

.info-item {
  margin-bottom: 12px;
  display: flex;
}

.info-item .label {
  font-weight: bold;
  margin-right: 10px;
  color: #606266;
  min-width: 60px;
}

.summary-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.summary-box {
  padding: 16px;
  background-color: #f8f9fa;
  border-radius: 4px;
  min-height: 200px;
  line-height: 1.6;
}

.ai-drawing {
  margin-top: 30px;
}

.drawing-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.generation-progress {
  margin-top: 20px;
}

.progress-text {
  margin-top: 8px;
  font-size: 14px;
  color: #606266;
}

.image-result {
  margin-top: 20px;
  border: 1px dashed #dcdfe6;
  border-radius: 4px;
  padding: 16px;
}

.image-url {
  margin-bottom: 16px;
}

.image-url p {
  margin-bottom: 8px;
}

.image-actions {
  display: flex;
  gap: 10px;
}
</style> 