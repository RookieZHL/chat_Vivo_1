import { createRouter, createWebHistory } from 'vue-router'
import UploadView from '../views/UploadView.vue'
import AnalysisView from '../views/AnalysisView.vue'
import Login from '../views/login/index.vue'
import Register from '../views/register/index.vue'
import Home from '../views/home/index.vue'
import Menu from '../views/menu/menu.vue'
const routes = [
  {
    path: '/',
    redirect: '/login' // 默认跳转到登录页
  },
  {
    path: '/login',
    name: 'Login',
    component: Login,
    meta: { title: '登录 - 蓝心创作助手' }
  },
  {
    path: '/menu',
    name: 'Menu',
    component: Menu,
    meta: { title: '菜单 - 蓝心创作助手' }
  },
  {
    path: '/register',
    name: 'Register',
    component: Register,
    meta: { title: '注册 - 蓝心创作助手' }
  },
  {
    path: '/home',
    name: 'Home',
    component: Home,
    meta: { 
      requiresAuth: true, 
      allowGuest: true,
      title: '蓝心创作助手 - 聊天'
    }
  },
  {
    path: '/upload',
    name: 'upload',
    component: UploadView
  },
  {
    path: '/analysis/:id',
    name: 'analysis',
    component: AnalysisView,
    props: true
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router 