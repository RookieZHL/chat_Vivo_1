import os
import time
import uuid
import json
import logging
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory, make_response
from flask_cors import CORS
from werkzeug.utils import secure_filename
import PyPDF2
import docx
import requests
from auth_util import gen_sign_headers

# 配置日志
logging.basicConfig(level=logging.DEBUG, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

app = Flask(__name__)
# 允许所有来源的跨域请求
CORS(app, resources={r"/*": {"origins": "*"}}, supports_credentials=True)

# 添加安全头部
@app.after_request
def add_headers(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type, X-Requested-With'
    response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS'
    return response

# 配置
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'uploads')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['ALLOWED_EXTENSIONS'] = {'pdf', 'docx', 'txt'}
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB限制

# 创建上传目录
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
logger.info(f"上传目录: {app.config['UPLOAD_FOLDER']}")

# vivo GPT配置
APP_ID = '2025802261'
APP_KEY = 'MtJDOAqjvfQiwmFW'
URI = '/vivogpt/completions'
DOMAIN = 'api-ai.vivo.com.cn'
METHOD = 'POST'

# 记录上传历史
HISTORY_FILE = os.path.join(app.config['UPLOAD_FOLDER'], 'history.json')
if not os.path.exists(HISTORY_FILE):
    with open(HISTORY_FILE, 'w') as f:
        json.dump([], f)
logger.info(f"历史记录文件: {HISTORY_FILE}")

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def get_file_extension(filename):
    return filename.rsplit('.', 1)[1].lower()

def extract_text_from_pdf(file_path):
    text = ""
    with open(file_path, 'rb') as file:
        pdf_reader = PyPDF2.PdfReader(file)
        for page_num in range(len(pdf_reader.pages)):
            text += pdf_reader.pages[page_num].extract_text()
    return text

def extract_text_from_docx(file_path):
    doc = docx.Document(file_path)
    text = ""
    for para in doc.paragraphs:
        text += para.text + "\n"
    return text

def extract_text_from_txt(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()

def extract_text(file_path, file_extension):
    if file_extension == 'pdf':
        return extract_text_from_pdf(file_path)
    elif file_extension == 'docx':
        return extract_text_from_docx(file_path)
    elif file_extension == 'txt':
        return extract_text_from_txt(file_path)
    return ""

def get_vivo_response(prompt):
    """调用vivo GPT API获取文本总结"""
    params = {'requestId': str(uuid.uuid4())}
    
    data = {
        'prompt': f"请对以下文本进行总结，最多250字：\n\n{prompt}",
        'model': 'vivo-BlueLM-TB-Pro',
        'sessionId': str(uuid.uuid4()),
        'extra': {
            'temperature': 0.7
        }
    }
    
    headers = gen_sign_headers(APP_ID, APP_KEY, METHOD, URI, params)
    headers['Content-Type'] = 'application/json'

    url = f'https://{DOMAIN}{URI}'
    response = requests.post(url, json=data, headers=headers, params=params)

    if response.status_code == 200:
        res_obj = response.json()
        if res_obj['code'] == 0 and res_obj.get('data'):
            return res_obj['data']['content']
    return "无法生成总结，请重试。"

def generate_image(prompt):
    """调用vivo AI绘画API生成图片"""
    # 提交绘图任务
    submit_uri = '/api/v1/task_submit'
    submit_params = {}
    submit_data = {
        'height': 1024,
        'width': 768,
        'prompt': prompt,
        'styleConfig': '7a0079b5571d5087825e52e26fc3518b',
        'userAccount': 'thisistestuseraccount'
    }

    submit_headers = gen_sign_headers(APP_ID, APP_KEY, 'POST', submit_uri, submit_params)
    submit_headers['Content-Type'] = 'application/json'

    submit_url = f'http://{DOMAIN}{submit_uri}'
    submit_response = requests.post(submit_url, data=json.dumps(submit_data), headers=submit_headers)
    
    if submit_response.status_code != 200:
        return None, "提交任务失败"

    submit_result = submit_response.json()
    if submit_result['code'] != 200:
        return None, submit_result['msg']

    task_id = submit_result['result']['task_id']

    # 查询任务进度
    progress_uri = '/api/v1/task_progress'
    progress_params = {'task_id': task_id}
    progress_headers = gen_sign_headers(APP_ID, APP_KEY, 'GET', progress_uri, progress_params)

    uri_params = '&'.join([f"{k}={v}" for k, v in progress_params.items()])
    progress_url = f'http://{DOMAIN}{progress_uri}?{uri_params}'
    
    # 记录任务状态
    status = {"task_id": task_id, "progress": 0, "status": "processing", "url": None}
    
    # 最多尝试60次，每次等待2秒
    for i in range(60):
        progress_response = requests.get(progress_url, headers=progress_headers)
        if progress_response.status_code != 200:
            status["status"] = "error"
            return None, "查询进度失败"

        progress_result = progress_response.json()
        if progress_result['code'] != 200:
            status["status"] = "error"
            return None, progress_result['msg']

        if progress_result['result']['finished']:
            image_url = progress_result['result']['images_url'][0]
            status["progress"] = 100
            status["status"] = "completed"
            status["url"] = image_url
            return image_url, None

        # 更新进度（估算）
        status["progress"] = min(95, (i + 1) * 2)
        time.sleep(2)  # 每2秒查询一次进度
    
    return None, "生成超时"

@app.route('/upload', methods=['POST'])
def upload_file():
    logger.info('收到文件上传请求')
    
    if 'file' not in request.files:
        logger.error('没有文件部分')
        return jsonify({'error': '没有文件'}), 400
    
    file = request.files['file']
    logger.info(f'上传的文件: {file.filename}')
    
    if file.filename == '':
        logger.error('未选择文件')
        return jsonify({'error': '未选择文件'}), 400
    
    if file and allowed_file(file.filename):
        try:
            # 安全地获取文件名并保存
            filename = secure_filename(file.filename)
            file_extension = get_file_extension(filename)
            file_id = str(uuid.uuid4())
            unique_filename = f"{file_id}_{filename}"
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
            logger.info(f'保存文件到: {file_path}')
            
            file.save(file_path)
            logger.info('文件保存成功')
            
            # 记录上传历史
            with open(HISTORY_FILE, 'r') as f:
                history = json.load(f)
            
            history_item = {
                'id': file_id,
                'filename': filename,
                'type': file_extension,
                'time': datetime.now().strftime('%Y-%m-%d %H:%M'),
                'path': file_path
            }
            history.append(history_item)
            
            with open(HISTORY_FILE, 'w') as f:
                json.dump(history, f)
                
            logger.info('历史记录更新成功')
            
            return jsonify({'success': True, 'id': file_id, 'filename': filename}), 200
            
        except Exception as e:
            logger.error(f'文件上传过程中出错: {str(e)}', exc_info=True)
            return jsonify({'error': f'文件上传失败: {str(e)}'}), 500
    
    logger.error(f'不支持的文件类型: {file.filename}')
    return jsonify({'error': '不支持的文件类型'}), 400

@app.route('/history', methods=['GET'])
def get_history():
    logger.info('获取历史记录')
    try:
        with open(HISTORY_FILE, 'r') as f:
            history = json.load(f)
        return jsonify(history)
    except Exception as e:
        logger.error(f'获取历史记录失败: {str(e)}', exc_info=True)
        return jsonify({'error': str(e)}), 500

@app.route('/analyze/<file_id>', methods=['GET'])
def analyze_file(file_id):
    logger.info(f'分析文件: {file_id}')
    
    try:
        with open(HISTORY_FILE, 'r') as f:
            history = json.load(f)
        
        file_info = None
        for item in history:
            if item['id'] == file_id:
                file_info = item
                break
        
        if not file_info:
            logger.error(f'文件不存在: {file_id}')
            return jsonify({'error': '文件不存在'}), 404
        
        # 提取文本
        file_path = file_info['path']
        file_extension = file_info['type']
        
        logger.info(f'从文件中提取文本: {file_path}')
        text = extract_text(file_path, file_extension)
        
        # 生成总结
        logger.info('生成文本总结')
        summary = get_vivo_response(text)
        
        return jsonify({
            'success': True,
            'filename': file_info['filename'],
            'type': file_extension,
            'text': text[:1000] + '...' if len(text) > 1000 else text,  # 只返回前1000个字符
            'summary': summary
        }), 200
    except Exception as e:
        logger.error(f'分析文件失败: {str(e)}', exc_info=True)
        return jsonify({'error': f'分析失败: {str(e)}'}), 500

@app.route('/generate-image', methods=['POST'])
def create_image():
    logger.info('生成图片请求')
    data = request.json
    if not data or 'prompt' not in data:
        logger.error('缺少prompt参数')
        return jsonify({'error': '缺少参数'}), 400
    
    prompt = data['prompt']
    logger.info(f'生成图片的提示词: {prompt[:100]}...')
    
    image_url, error = generate_image(prompt)
    
    if error:
        logger.error(f'生成图片失败: {error}')
        return jsonify({'error': error}), 500
    
    logger.info(f'图片生成成功: {image_url}')
    return jsonify({'success': True, 'url': image_url}), 200

@app.route('/task-status/<task_id>', methods=['GET'])
def task_status(task_id):
    logger.info(f'查询任务状态: {task_id}')
    # 这里可以实现任务状态查询，此示例简化处理
    progress_uri = '/api/v1/task_progress'
    progress_params = {'task_id': task_id}
    progress_headers = gen_sign_headers(APP_ID, APP_KEY, 'GET', progress_uri, progress_params)

    uri_params = '&'.join([f"{k}={v}" for k, v in progress_params.items()])
    progress_url = f'http://{DOMAIN}{progress_uri}?{uri_params}'
    
    progress_response = requests.get(progress_url, headers=progress_headers)
    if progress_response.status_code != 200:
        logger.error(f'查询任务状态失败: {progress_response.status_code}')
        return jsonify({"status": "error", "message": "查询失败"}), 500

    progress_result = progress_response.json()
    if progress_result['code'] != 200:
        logger.error(f'查询任务状态错误: {progress_result["msg"]}')
        return jsonify({"status": "error", "message": progress_result['msg']}), 500

    if progress_result['result']['finished']:
        image_url = progress_result['result']['images_url'][0]
        logger.info(f'任务已完成: {image_url}')
        return jsonify({
            "status": "completed",
            "progress": 100,
            "url": image_url
        })
    
    # 估计进度
    logger.info(f'任务进行中: {task_id}')
    return jsonify({
        "status": "processing",
        "progress": 50  # 假设进度
    })

@app.route('/')
def index():
    return "文档分析API服务"

if __name__ == '__main__':
    app.run(debug=True, port=5001) 