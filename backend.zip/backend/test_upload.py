import requests
import os
import json
import time
import socket

def check_server_running(host='localhost', port=5001, timeout=2):
    """检查服务器是否运行"""
    try:
        socket.setdefaulttimeout(timeout)
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((host, port))
        s.close()
        return True
    except socket.error as e:
        print(f"无法连接到服务器 {host}:{port}，错误: {e}")
        return False

def test_upload():
    # 首先检查服务器是否运行
    if not check_server_running():
        print("错误: 请确保Flask服务器正在运行 (python app.py --port=5001)")
        return

    # 创建一个测试文本文件
    test_file_path = 'test_file.txt'
    with open(test_file_path, 'w') as f:
        f.write('这是一个测试文件内容。\n用于测试文件上传功能。')
    
    print(f"创建测试文件: {test_file_path}")
    
    # 上传文件
    url = 'http://localhost:5001/upload'
    files = {'file': open(test_file_path, 'rb')}
    headers = {
        'Accept': 'application/json'
    }
    
    print(f"发送POST请求到: {url}")
    print(f"请求头: {headers}")
    try:
        response = requests.post(url, files=files, headers=headers)
        
        # 输出结果
        print(f"状态码: {response.status_code}")
        print(f"响应头: {response.headers}")
        print(f"响应内容: {response.text}")
        
        if response.status_code == 200:
            try:
                data = response.json()
                print(f"成功上传文件，ID: {data.get('id')}")
                file_id = data.get('id')
                
                # 测试获取历史记录
                history_url = 'http://localhost:5001/history'
                print(f"\n获取历史记录: {history_url}")
                history_response = requests.get(history_url)
                print(f"历史状态码: {history_response.status_code}")
                if history_response.status_code == 200:
                    print(f"历史记录: {json.dumps(history_response.json(), indent=2, ensure_ascii=False)}")
                
                # 测试文件分析
                if file_id:
                    analyze_url = f'http://localhost:5001/analyze/{file_id}'
                    print(f"\n分析文件: {analyze_url}")
                    try:
                        analyze_response = requests.get(analyze_url)
                        print(f"分析状态码: {analyze_response.status_code}")
                        if analyze_response.status_code == 200:
                            print(f"分析结果: {json.dumps(analyze_response.json(), indent=2, ensure_ascii=False)}")
                    except Exception as e:
                        print(f"分析请求错误: {str(e)}")
            except json.JSONDecodeError:
                print("响应不是有效的JSON格式")
        else:
            print(f"请求失败，状态码: {response.status_code}")
            print(f"可能原因: 服务器返回了非200状态码，检查服务器日志获取更多信息")
    except Exception as e:
        print(f"请求发生错误: {str(e)}")
    finally:
        # 关闭文件
        files['file'].close()
    
    # 删除测试文件
    os.remove(test_file_path)
    print(f"删除测试文件: {test_file_path}")

if __name__ == '__main__':
    test_upload() 